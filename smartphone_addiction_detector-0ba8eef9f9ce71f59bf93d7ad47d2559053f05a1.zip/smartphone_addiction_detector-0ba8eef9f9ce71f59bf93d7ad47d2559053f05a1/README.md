# ML-Based-Smartphone-Addiction-Prediction
This project predicts smartphone addiction using machine learning. It includes data collection, model training, evaluation, and deployment. Our goal is to create a tool to identify and help mitigate smartphone addiction based on user behavior patterns
