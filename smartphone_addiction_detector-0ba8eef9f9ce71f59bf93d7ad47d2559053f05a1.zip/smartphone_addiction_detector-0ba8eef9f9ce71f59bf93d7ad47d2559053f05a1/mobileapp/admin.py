from django.contrib import admin
from .models import Register,UserPrediction,UserHistory
admin.site.register(Register)
admin.site.register(UserPrediction)
admin.site.register(UserHistory)
# Register your models here.
